var 
options={series:[90],	
	labels:['Open'],
	chart:{height:150,type:"radialBar"},
	plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
	dataLabels:{name:{show:!0},value:{show:!0,fontSize:"12px",offsetY:5},style:{colors:["#fff"]}}}},
	colors:["#3b5de7"]};
	(
		chart=new ApexCharts(
			document.querySelector("#radial-chart-1"),
			options)
		)
		.render();

		options={series:[2],
			labels:['Fixed'],
			chart:{height:150,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#00edd7"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-2"),
			options)
		)
		.render();

		options={series:[8],
			labels:['Closed'],
			chart:{height:150,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#ff6600"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-3"),
			options)
		)
		.render();		

		options={series:[8],
			labels:['Closed'],
			chart:{height:150,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#ff0000"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-10"),
			options)
		)
		.render();		

		options={series:[8],
			labels:['Open'],
			chart:{height:150,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#3b5de7"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-11"),
			options)
		)
		.render();				

		options={series:[8],
			labels:['False Positive'],
			chart:{height:150,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#BA55D3"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-14"),
			options)
		)
		.render();				


		options={series:[200],
			labels:['Total'],
			chart:{height:285,type:"radialBar"},
			plotOptions:{radialBar:{offsetY:-12,hollow:{margin:0,size:"60%",background:"#fff"},
			dataLabels:{name:{show:!0},

						value:{show:!0,fontSize:"12px",offsetY:5},
						style:{colors:["#fff"]}}}},
						colors:["#ff0000"]};
		(
			chart=new ApexCharts(document.querySelector("#radial-chart-4"),
			options)
		)
		.render();				

		options={series:[{name:"Series A",
		type:"column",data:[23,11,53,27,13,19,22,37,21,44,22,30]},
		{name:"Series B",type:"area",data:[36,47,33,41,22,37,43,21,41,56,27,43]},
		{name:"Series C",type:"line",data:[46,57,43,51,32,47,53,31,51,66,37,53]}],
		chart:{height:275,type:"line",stacked:!1,toolbar:{show:!1}},
		stroke:{width:[0,2,2],
			curve:"smooth",
			dashArray:[0,0,4]},
			plotOptions:{bar:{columnWidth:"15%",endingShape:"rounded"}},
			fill:{opacity:[.85,.25,1],
				gradient:{inverseColors:!1,shade:"light",type:"vertical",
				opacityFrom:.85,
				opacityTo:.55,stops:[0,100,100,100]}},
				xaxis:{categories:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]},
				colors:["#3b5de7","#eeb902","#5fd195"],
				markers:{size:0}};(chart=new ApexCharts(document.querySelector("#mixed-chart"),options)).render();
				options={series:[{name:"Series A",data:[24,66,42,88,62,24,45,12,36,10]}],chart:{height:100,type:"line",sparkline:{enabled:!0},toolbar:{show:!1}},dataLabels:{enabled:!1},stroke:{curve:"smooth",width:3},colors:["#3b5de7"]};(chart=new ApexCharts(document.querySelector("#sales-report-chart"),options)).render();

				options={
				series:[
						{
							data:[9,3,5,25,160]
						}
						],
				chart:{				
					type:"bar",
					height:250,					
					toolbar:{show:!0}
					},
				plotOptions:
					{
						bar:
							{
							horizontal:true,
							distributed: true,
							barHeight:"34%",
							endingShape:"rounded",							
							}
					},
					colors:["#4c58df","#00cc7f","#ffb640","#ff0000","#900101"],
				dataLabels:{enabled:!1},				
				xaxis:{
						categories:["Informaational 40","Low 60","Medium 50","High 30","Critical 20"],
						title:{text:"Thousands"},
						
				}				
				};

				(chart=new ApexCharts(document.querySelector("#bar-chart"),options)).render();

				var chart;
				options={series:[
				{name:"Series 1",
				data:[80,50,30,40,100,20]},
				{name:"Series 2",
				data:[20,30,40,80,20,80]},
				{name:"Series 3",
				data:[44,76,78,13,43,10]}],
				chart:{height:250,
					type:"radar",
				dropShadow:{enabled:!0,blur:1,left:1,top:1},
				toolbar:{show:!1}},
				stroke:{width:0},
				fill:{opacity:.4},
				markers:{size:0},
				colors:["#3b5de7","#5fd195","#eeb902"],
				xaxis:{categories:["2014","2015","2016","2017","2018","2019"]}};
				(chart=new ApexCharts(document.querySelector("#radar-chart"),options)).render();